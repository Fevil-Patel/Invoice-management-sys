<?php

namespace App\Mail;

use App\Models\Invoice;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class InvoiceMail extends Mailable
{
    use Queueable, SerializesModels;

    public $invoice;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Invoice $invoice)
    {
        $this->invoice = $invoice;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $pdf = PDF::loadView('invoices.invoiceView', ['invoice' => $this->invoice])->output();

        return $this->from(env('MAIL_FROM_ADDRESS'), env('MAIL_FROM_NAME'))
                    ->subject('Your Invoice #' . $this->invoice->invoice_number)
                    ->view('invoices.invoiceView', ['invoice' => $this->invoice])
                    ->attachData($pdf, 'invoice_' . $this->invoice->id . '.pdf', [
                        'mime' => 'application/pdf',
                    ]);
    }
}
