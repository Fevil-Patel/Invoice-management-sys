<?php

namespace App\Http\Controllers;

use App\Models\Invoice;
use App\Models\Product;
use App\Models\User;
use App\Models\Vendor;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $totalProduct = Product::where('is_delete',0)->count();
        $totalVendor = Vendor::where('is_delete',0)->count();
        $totalInvoice = Invoice::where('is_delete',0)->count();
        return view('home',compact('totalProduct','totalVendor','totalInvoice'));
    }
}
