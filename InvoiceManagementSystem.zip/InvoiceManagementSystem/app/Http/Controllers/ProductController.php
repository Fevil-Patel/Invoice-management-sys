<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    //
    public function ViewProduct()
    {
        $productList = Product::where('is_delete', 0)->get();
        return view('products.view',compact('productList'));
    }

    public function DeleteProduct(Request $request){
        $updateProduct = Product::where('id',$request->id)->update(['is_delete' => 1]);
        if($updateProduct){
            return response()->json(['status' => 'success', 'message' => 'Product deleted successfully!']);
        }else{
            return response()->json(['status' => 'error', 'message' => 'Product not found!']);
        }
    }

    public function CreateProduct(Request $request){
        try {
            $request->validate([
                'name' => 'required',
                'image' => 'required|image|mimes:jpeg,png,jpg|max:2048',
                'unit' => 'required',
                'price' => 'required|numeric',
            ]);
    
            $imageName = time().'.'.$request->image->getClientOriginalName();
            $request->image->storeAs('uploads/products', $imageName, 'public');
    
            $product = Product::create([
                'name' => $request->name,
                'image' => $imageName,
                'unit' => $request->unit,
                'price' => $request->price,
            ]);
            
            if($product){
                return json_encode(['status' => 'success', 'message' => 'Product created successfully!']);       
            }else{
                return json_encode(['status' => 'error', 'message' => 'Product not created!']);       
            } 
        } catch (\Throwable $th) {
            return json_encode(['status' => 'error', 'message' => 'Something went wrong!']);
        }
    }

    public function EditProduct(Request $request){
        $product = Product::where('id',$request->id)->first();
        if($product){
            return json_encode(['status' => 'success', 'message' => 'Product found!', 'data' => $product]);
        }else{  
            return json_encode(['status' => 'error', 'message' => 'Product not found!']);
        }
        return json_encode($product);
    }

    public function UpdateProduct(Request $request){
        try {
            $rules = [
                'name' => 'required',
                'unit' => 'required',
                'price' => 'required|numeric',
            ];
    
            if ($request->hasFile('image')) {
                $rules['image'] = 'image|mimes:jpeg,png,jpg|max:2048';
            }
    
            $request->validate($rules);
    
            if($request->hasFile('image')){
                $imageName = time().'.'.$request->image->getClientOriginalName();
                $request->image->storeAs('uploads/products', $imageName, 'public');
                $product = Product::where('id',$request->product_id)->update([
                    'name' => $request->name,
                    'image' => $imageName,
                    'unit' => $request->unit,
                    'price' => $request->price,
                ]);
            }else{
                $product = Product::where('id',$request->product_id)->update([
                    'name' => $request->name,
                    'unit' => $request->unit,
                    'price' => $request->price,
                ]);
            }
            
            if($product){
                return json_encode(['status' => 'success', 'message' => 'Product updated successfully!']);
            }else{  
                return json_encode(['status' => 'error', 'message' => 'Product not updated!']);
            }
        } catch (\Throwable $th) {
            return json_encode(['status' => 'error', 'message' => 'Something went wrong!']);
        }        
    }
}
