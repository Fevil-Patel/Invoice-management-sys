<?php

namespace App\Http\Controllers;

use App\Mail\InvoiceMail;
use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\Product;
use App\Models\Vendor;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class InvoiceController extends Controller
{
    //
    public function ViewInvoice()
    {
        $vendors = Vendor::where('is_delete',0)->get();
        $products = Product::where('is_delete',0)->get();
        $invoices = Invoice::with('vendor')->where('is_delete',0)->get();
        return view('invoices.view',compact('vendors','products','invoices'));
    }

    public function storeInvoice(Request $request)
    {
        $request->validate([
            'vendor_id' => 'required',
            'products' => 'required|array',
            'quantity' => 'required|array',
            'price' => 'required|array',
            'grand_total' => 'required|numeric',
        ]);

        $invoiceNumber = 'INV-' . str_pad(Invoice::count() + 1, 6, '0', STR_PAD_LEFT);

        $invoice = Invoice::create([
            'user_id' => auth()->user()->id,
            'vendor_id' => $request->vendor_id,
            'invoice_number' => $invoiceNumber,
            'description' => $request->description,
            'grand_total' => $request->grand_total,
        ]);

        foreach ($request->products as $key => $product) {
            InvoiceItem::create([
                'invoice_id' => $invoice->id,
                'product_id' => $product,
                'price' => $request->price[$key],
                'quantity' => $request->quantity[$key],
                'total' => $request->price[$key] * $request->quantity[$key],
            ]);
        }

        return response()->json(['status' => 'success', 'message' => 'Invoice saved successfully!']);
    }

    public function EditInvoice(Request $request)
    {
        $invoice = Invoice::with('items.product')->find($request->id);
        if (!$invoice) {
            return response()->json(['success' => false, 'message' => 'Invoice not found'], 404);
        }
    
        return response()->json([
            'success' => true,
            'data' => [
                'id' => $invoice->id,
                'vendor_id' => $invoice->vendor_id,
                'description' => $invoice->description,
                'grand_total' => $invoice->grand_total,
                'items' => $invoice->items->map(function ($item) {
                    return [
                        'product_id' => $item->product_id,
                        'price' => $item->price,
                        'quantity' => $item->quantity,
                        'total' => $item->total
                    ];
                }),
            ]
        ]);
    }

    public function UpdateInvoice(Request $request)
    {
        $request->validate([
            'invoice_id' => 'required',
            'vendor_id' => 'required',
            'products' => 'required|array',
            'quantity' => 'required|array',
            'price' => 'required|array',
            'grand_total' => 'required|numeric',
        ]);
    
        $invoice = Invoice::findOrFail($request->invoice_id);
        $invoice->update([
            'vendor_id' => $request->vendor_id,
            'description' => $request->description,
            'grand_total' => $request->grand_total,
        ]);
    
        // Delete old items
        InvoiceItem::where('invoice_id', $invoice->id)->delete();
    
        // Add updated items
        foreach ($request->products as $key => $product) {
            InvoiceItem::create([
                'invoice_id' => $invoice->id,
                'product_id' => $product,
                'price' => $request->price[$key],
                'quantity' => $request->quantity[$key],
                'total' => $request->price[$key] * $request->quantity[$key],
            ]);
        }
    
        return response()->json(['message' => 'Invoice updated successfully!']);
    }

    public function downloadInvoice($id)
    {
        $invoice = Invoice::with('items.product', 'vendor')->findOrFail($id);
        $pdf = PDF::loadView('invoices.invoiceView', compact('invoice'));
        return $pdf->download('invoice_' . $id . '.pdf');
    }

    public function sendInvoice($id)
    {
        $invoice = Invoice::with('items.product', 'vendor')->findOrFail($id);
        
        // Change to actual customer email
        $customerEmail = "test@yopmail.com"; 

        Mail::to($customerEmail)->send(new InvoiceMail($invoice));

        return response()->json(['success' => 'Invoice sent successfully!']);
    }
}
