<?php

namespace App\Http\Controllers;

use App\Models\Vendor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class VendorController extends Controller
{
    public function ViewVendor()
    {
        $vendorList = Vendor::where('is_delete', 0)->get();
        return view('vendors.view',compact('vendorList'));
    }

    public function createVendor(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'vendor_name' => 'required',
            'vendor_companyname' => 'required',
            'vendor_companyaddress' => 'required',
            'vendor_GST' => 'required|min:10|max:15',
            'vendor_currency' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 'error', 'errors' => $validator->errors()], 422);
        }

        $vendor = Vendor::create($request->all());

        return response()->json(['status' => 'success', 'message' => 'Vendor added successfully!', 'data' => $vendor]);
    }

    public function deleteVendor(Request $request)
    {
        $updateVendor = Vendor::where('id',$request->id)->update(['is_delete' => 1]);
        if($updateVendor){
            return response()->json(['status' => 'success', 'message' => 'Vendor deleted successfully!']);
        }else{
            return response()->json(['status' => 'error', 'message' => 'Vendor not found!']);
        }
    }

    public function editVendor(Request $request)
    {
        $vendor = Vendor::where('id',$request->id)->first();
        if($vendor){
            return response()->json(['status' => 'success', 'data' => $vendor]);
        }else{
            return response()->json(['status' => 'error', 'message' => 'Vendor not found!']);
        }
    }

    public function updateVendor(Request $request)
    {
        $updateVendor = Vendor::where('id',$request->vendor_id)->update([
            'vendor_name' => $request->vendor_name,
            'vendor_companyname' => $request->vendor_companyname,
            'vendor_companyaddress' => $request->vendor_companyaddress,
            'vendor_GST' => $request->vendor_GST,
            'vendor_currency' => $request->vendor_currency,
        ]);
        if($updateVendor){
            return response()->json(['status' => 'success', 'message' => 'Vendor updated successfully!']);
        }else{
            return response()->json(['status' => 'error', 'message' => 'Vendor not found!']);
        }
    }

}
