@extends('theme-layouts.theme-app')

@section('content')
<h2>Invoice Section</h2>
<br>
<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#invoiceModal">
  Add Invoice
</button>
<br>
<br>
<div class="table-responsive small">
  <table class="table table-striped table-sm">
    <thead>
      <tr>
        <th scope="col">Sr.no</th>
        <th scope="col">VendorName</th>
        <th scope="col">GrandTotal</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      @php
        $count = 1;    
      @endphp
      @foreach($invoices as $invoice)
      <tr>
        <td>{{ $count++ }}</td>
        <td>{{ $invoice->vendor->vendor_name }}</td>
        <td>{{ $invoice->grand_total }}</td>
        <td>
          <a id="editInvoice" data-id="{{ $invoice->id }}" class="btn btn-primary btn-sm">Edit</a>
          <a id="deleteInvoice" data-id="{{ $invoice->id }}" class="btn btn-danger btn-sm">Delete</a>
          <a id="downloadInvoice" data-id="{{ $invoice->id }}" class="btn btn-danger btn-sm">Download PDF</a>
          <a id="sendInvoice" data-id="{{ $invoice->id }}" class="btn btn-danger btn-sm">SEND Invoice</a>
        </td>
      </tr>
      @endforeach
      
    </tbody>
  </table>
</div>

<!-- Invoice Modal -->
<div class="modal fade" id="invoiceModal" tabindex="-1" aria-labelledby="invoiceModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
      <div class="modal-content">
          <div class="modal-header">
              <h5 class="modal-title">Create Invoice</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <form id="invoiceForm">
              <div class="modal-body">
                  @csrf
                  <input type="hidden" name="invoice_id" id="invoice_id" value="">
                  <!-- Select Vendor -->
                  <div class="mb-3">
                      <label for="vendor" class="form-label">Choose Vendor</label>
                      <select id="vendor" class="form-control" name="vendor_id">
                          <option value="">Select Vendor</option>
                          @foreach($vendors as $vendor)
                              <option value="{{ $vendor->id }}">{{ $vendor->vendor_name }}</option>
                          @endforeach
                      </select>
                  </div>

                  <!-- Products Table -->
                  <table class="table table-bordered">
                      <thead>
                          <tr>
                              <th>Product</th>
                              <th>Price</th>
                              <th>Quantity</th>
                              <th>Total</th>
                              <th>Action</th>
                          </tr>
                      </thead>
                      <tbody id="invoiceItems">
                          <tr>
                              <td>
                                  <select class="form-control product-select" name="products[]">
                                      <option value="">Select Product</option>
                                      @foreach($products as $product)
                                          <option value="{{ $product->id }}" data-price="{{ $product->price }}">{{ $product->name }}</option>
                                      @endforeach
                                  </select>
                              </td>
                              <td><input type="text" class="form-control price" name="price[]" readonly></td>
                              <td><input type="number" class="form-control quantity" name="quantity[]" value="1" min="1"></td>
                              <td><input type="text" class="form-control total" name="total[]" readonly></td>
                              <td><button type="button" class="btn btn-danger remove-item">X</button></td>
                          </tr>
                      </tbody>
                  </table>

                  <!-- Add More Product Button -->
                  <button type="button" class="btn btn-secondary" id="addProduct">Add Product</button>

                  <!-- Description -->
                  <div class="mb-3">
                      <label for="description" class="form-label">Description</label>
                      <textarea id="description" class="form-control" name="description"></textarea>
                  </div>

                  <!-- Grand Total -->
                  <div class="mb-3">
                      <label for="grandTotal" class="form-label">Grand Total</label>
                      <input type="text" class="form-control" id="grandTotal" name="grand_total" readonly>
                  </div>
              </div>

              <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary">Save Invoice</button>
              </div>
          </form>
      </div>
  </div>
</div>

<script>
  $(document).ready(function () {
    function updateTotal() {
        let grandTotal = 0;
        $("#invoiceItems tr").each(function () {
            let price = parseFloat($(this).find(".price").val()) || 0;
            let quantity = parseFloat($(this).find(".quantity").val()) || 1;
            let total = price * quantity;
            $(this).find(".total").val(total.toFixed(2));
            grandTotal += total;
        });
        $("#grandTotal").val(grandTotal.toFixed(2));
    }

    // When selecting a product, update the price
    $(document).on("change", ".product-select", function () {
        let price = $(this).find(":selected").data("price") || 0;
        let row = $(this).closest("tr");
        row.find(".price").val(price);
        row.find(".quantity").val(1);
        row.find(".total").val(price);
        updateTotal();
    });

    // Update total on quantity change
    $(document).on("input", ".quantity", function () {
        updateTotal();
    });

    // Add new product row
    $("#addProduct").click(function () {
        let newRow = $("#invoiceItems tr:first").clone();
        newRow.find("select, input").val("");
        $("#invoiceItems").append(newRow);
    });

    // Remove product row
    $(document).on("click", ".remove-item", function () {
        $(this).closest("tr").remove();
        updateTotal();
    });

    // Save Invoice
    $("#invoiceForm").submit(function (e) {
        e.preventDefault();
        let formData = new FormData(this);
        var invoice_id = $('#invoice_id').val();
        if (invoice_id) {
            $url = "{{ route('invoice.update') }}";
        }else{
            $url = "{{ route('invoice.store') }}";
        }
        $.ajax({
            url: $url,
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            dataType: "json",
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
            },
            success: function (response) {
                console.log(response);
                if (invoice_id) {
                  alert('Invoice updated successfully!');
                }else{
                  alert('Invoice saved successfully!');
                }
                // Handle success response
            },
            error: function (xhr, status, error) {
                console.log(error);
                alert('Something went wrong!');
                // Handle error response
            }
        });
    });

    // Edit Invoice
    $(document).on("click", "#editInvoice", function () {
            $.ajax({
                url: "{{ route('invoice.edit') }}", // Laravel route for editing vendor
                type: "GET",
                data: { id: $(this).data("id") },
                dataType: "json",
                success: function (response) {
                  console.log(response.data);
                  
                    $('#invoiceModal').modal('show');
                    $('#vendor').val(response.data.vendor_id);
                    $('#description').val(response.data.description);
                    $('#grandTotal').val(response.data.grand_total);
                    $('#invoice_id').val(response.data.id);
                    
                    // Clear existing rows before adding new ones
                    $('#invoiceItems').empty();

                    // Loop through invoice items
                    $.each(response.data.items, function (index, item) {
                        var newRow = `
                            <tr>
                                <td>
                                    <select class="form-control product-select" name="products[]">
                                        <option value="">Select Product</option>
                                        ${generateProductOptions(item.product_id)}
                                    </select>
                                </td>
                                <td><input type="text" class="form-control price" name="price[]" value="${item.price}" readonly></td>
                                <td><input type="number" class="form-control quantity" name="quantity[]" value="${item.quantity}" min="1"></td>
                                <td><input type="text" class="form-control total" name="total[]" value="${item.total}" readonly></td>
                                <td><button type="button" class="btn btn-danger remove-item">X</button></td>
                            </tr>
                        `;
                        $('#invoiceItems').append(newRow);
                    });
                },
                error: function () {
                    alert("Something went wrong!");
                }
            });
        });

        function generateProductOptions(selectedId) {
          var options = `<option value="">Select Product</option>`;
          @foreach ($products as $product)
              options += `<option value="{{ $product->id }}" data-price="{{ $product->price }}" ${selectedId == {{ $product->id }} ? 'selected' : ''}>{{ $product->name }}</option>`;
          @endforeach
          return options;
      }

      $(document).on("click", "#downloadInvoice", function () {
        var invoiceId = $(this).data('id');
          window.location.href = "{{ route('invoice.download', ':id') }}".replace(':id', invoiceId);
      });

      $(document).on("click", "#sendInvoice", function () {
        var invoiceId = $(this).data('id');
          window.location.href = "{{ route('invoice.send', ':id') }}".replace(':id', invoiceId);
      });
});
</script>
@endsection