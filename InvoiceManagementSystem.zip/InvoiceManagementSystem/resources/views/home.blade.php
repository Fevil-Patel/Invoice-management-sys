@extends('theme-layouts.theme-app')

@section('content')
<h1>Dashboard</h1>
<div class="col-md-3">
    <div class="card text-white bg-primary mb-3">
        <div class="card-body text-center">
            <h5 class="card-title">Total Product</h5>
            <h3 class="card-text">{{ $totalProduct }}</h3>
        </div>
    </div>
</div>
<div class="col-md-3">
    <div class="card text-white bg-primary mb-3">
        <div class="card-body text-center">
            <h5 class="card-title">Total Vendor</h5>
            <h3 class="card-text">{{ $totalVendor }}</h3>
        </div>
    </div>
</div>
<div class="col-md-3">
    <div class="card text-white bg-primary mb-3">
        <div class="card-body text-center">
            <h5 class="card-title">Total Invoice</h5>
            <h3 class="card-text">{{ $totalInvoice }}</h3>
        </div>
    </div>
</div>
@endsection