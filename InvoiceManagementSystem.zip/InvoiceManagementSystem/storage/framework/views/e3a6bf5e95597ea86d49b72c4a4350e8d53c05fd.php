<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice #<?php echo e($invoice->id); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .invoice-box {
            max-width: 800px;
            margin: auto;
            padding: 20px;
            border: 1px solid #eee;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
            font-size: 14px;
            line-height: 24px;
            color: #555;
        }
        .title {
            font-size: 20px;
            font-weight: bold;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
            text-align: left;
        }
        .total {
            font-weight: bold;
        }
    </style>
</head>
<body>

    <div class="invoice-box">
        <table>
            <tr>
                <td class="title">INVOICE</td>
                <td style="text-align: right;">Invoice No: <?php echo e($invoice->invoice_number); ?></td>
            </tr>
            <tr>
                <td>Vendor: <strong><?php echo e($invoice->vendor->vendor_name); ?></strong></td>
                <td style="text-align: right;">Date: <?php echo e($invoice->created_at->format('d M, Y')); ?></td>
            </tr>
        </table>

        <table>
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->product->name); ?></td>
                    <td>$<?php echo e(number_format($item->product->price, 2)); ?></td>
                    <td><?php echo e($item->quantity); ?></td>
                    <td>$<?php echo e(number_format($item->product->price * $item->quantity, 2)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3" class="total">Grand Total</td>
                    <td class="total">$<?php echo e(number_format($invoice->grand_total, 2)); ?></td>
                </tr>
            </tfoot>
        </table>

        <p><strong>Description:</strong> <?php echo e($invoice->description); ?></p>
        <p>Thank you for your business!</p>
    </div>

</body>
</html>
<?php /**PATH E:\Coding-Language-Learn\IMS-Laravel\InvoiceManagementSystem\resources\views/invoices/invoiceView.blade.php ENDPATH**/ ?>