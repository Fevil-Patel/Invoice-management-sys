<?php $__env->startSection('content'); ?>
<h1>Dashboard</h1>
<div class="col-md-3">
    <div class="card text-white bg-primary mb-3">
        <div class="card-body text-center">
            <h5 class="card-title">Total Product</h5>
            <h3 class="card-text"><?php echo e($totalProduct); ?></h3>
        </div>
    </div>
</div>
<div class="col-md-3">
    <div class="card text-white bg-primary mb-3">
        <div class="card-body text-center">
            <h5 class="card-title">Total Vendor</h5>
            <h3 class="card-text"><?php echo e($totalVendor); ?></h3>
        </div>
    </div>
</div>
<div class="col-md-3">
    <div class="card text-white bg-primary mb-3">
        <div class="card-body text-center">
            <h5 class="card-title">Total Invoice</h5>
            <h3 class="card-text"><?php echo e($totalInvoice); ?></h3>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme-layouts.theme-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding-Language-Learn\IMS-Laravel\InvoiceManagementSystem\resources\views/home.blade.php ENDPATH**/ ?>