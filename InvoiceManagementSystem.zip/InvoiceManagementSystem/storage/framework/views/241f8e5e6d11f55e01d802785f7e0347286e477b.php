

<?php $__env->startSection('content'); ?>
<h2>Vendor Section</h2>
<br>
<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#vendorModal">
  Add Vendor
</button>
      <br>
      <br>
      <div class="table-responsive small">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th scope="col">Sr.no</th>
              <th scope="col">Name</th>
              <th scope="col">Company</th>
              <th scope="col">Address</th>
              <th scope="col">GST</th>
              <th scope="col">Currency</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php
              $count = 1;    
            ?>
            <?php $__currentLoopData = $vendorList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($count++); ?></td>
              <td><?php echo e($vendor->vendor_name); ?></td>
              <td><?php echo e($vendor->vendor_companyname); ?></td>
              <td><?php echo e($vendor->vendor_companyaddress); ?></td>
              <td><?php echo e($vendor->vendor_GST); ?></td>
              <td><?php echo e($vendor->vendor_currency); ?></td>
              <td>
                <a id="editVendor" data-id="<?php echo e($vendor->id); ?>" class="btn btn-primary btn-sm">Edit</a>
                <a id="deleteVendor" data-id="<?php echo e($vendor->id); ?>" class="btn btn-danger btn-sm">Delete</a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </tbody>
        </table>
      </div>

      <!-- Modal -->
      <div class="modal fade" id="vendorModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Add New Vendor</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" id="vendorForm">
              <?php echo csrf_field(); ?>
              <div class="modal-body">
                <input type="hidden" name="vendor_id" id="vendor_id" value="">
                <div class="mb-3">
                  <label for="vendor_name" class="form-label">Vendor Full Name</label>
                  <input type="text" class="form-control" id="vendor_name" name="vendor_name" required>
                </div>
                <div class="mb-3">
                  <label for="vendor_companyname" class="form-label">Company Name</label>
                  <input type="text" class="form-control" id="vendor_companyname" name="vendor_companyname" required>
                </div>
                <div class="mb-3">
                  <label for="vendor_companyaddress" class="form-label">Company Address</label>
                  <textarea class="form-control" id="vendor_companyaddress" name="vendor_companyaddress" rows="2" required></textarea>
                </div>
                <div class="mb-3">
                  <label for="vendor_GST" class="form-label">GST Number</label>
                  <input type="text" class="form-control" id="vendor_GST" name="vendor_GST" required>
                </div>
                <div class="mb-3">
                  <label for="vendor_currency" class="form-label">Currency</label>
                  <select class="form-control" id="vendor_currency" name="vendor_currency" required>
                    <option value="INR">INR</option>
                    <option value="USD">USD</option>
                    <option value="EUR">EUR</option>
                  </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Vendor</button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <script>
        $(document).ready(function () {
            $("#vendorForm").validate({
                errorClass: "errorClass",              
                rules: {
                  vendor_name: { required: true},
                    vendor_companyname: { required: true },
                    vendor_companyaddress: { required: true },
                    vendor_GST: { required: true, minlength: 10, maxlength: 15 },
                    vendor_currency: { required: true }
                },
                messages: {
                  vendor_name: { required: "Vendor name is required"},
                    vendor_companyname: { required: "Company name is required" },
                    vendor_companyaddress: { required: "Company address is required" },
                    vendor_GST: { required: "GST Number is required", minlength: "Minimum 10 characters", maxlength: "Maximum 15 characters" },
                    vendor_currency: { required: "Please select a currency" }
                },
                submitHandler: function (form) {
                    $vendorID = $("#vendor_id").val();
                    if ($vendorID) {
                        $url = "<?php echo e(route('vendor.update')); ?>";
                    } else {
                        $url = "<?php echo e(route('vendor.store')); ?>";
                    }
                    $.ajax({
                        url: $url, // Laravel route for storing vendor
                        type: "POST",
                        data: $("#vendorForm").serialize(),
                        beforeSend: function () {
                            $(".btn-primary").prop("disabled", true).text("Saving...");
                        },
                        success: function (response) {
                            if (response.status === "success") {
                              if ($vendorID) {
                                alert("Vendor updated successfully!");
                              }else{
                                alert("Vendor added successfully!");
                              }
                                $("#exampleModal").modal("hide");
                                $("#vendorForm")[0].reset();
                            } else {
                                $("#errorMessages").removeClass("d-none").html(response.message);
                            }
                        },
                        error: function (xhr) {
                            let errors = xhr.responseJSON.errors;
                            let errorMessage = "<ul>";
                            $.each(errors, function (key, value) {
                                errorMessage += "<li>" + value[0] + "</li>";
                            });
                            errorMessage += "</ul>";
                            $("#errorMessages").removeClass("d-none").html(errorMessage);
                        },
                        complete: function () {
                            $(".btn-primary").prop("disabled", false).text("Save Vendor");
                        }
                    });
                }
            });
        });

        $(document).on("click", "#deleteVendor", function () {
            if (confirm("Are you sure you want to delete this vendor?")) {
                $.ajax({
                    url: "<?php echo e(route('vendor.delete')); ?>", // Laravel route for deleting vendor
                    type: "POST",
                    data: { id: $(this).data("id") },
                    dataType: "json",
                    headers: {
                        "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
                    },
                    success: function (response) {
                        if (response.status === "success") {
                            alert("Vendor deleted successfully!");
                        } else {
                            alert("Something went wrong!");
                        }
                    },
                    error: function () {
                        alert("Something went wrong!");
                    }
                });
            }
        });

        $(document).on("click", "#editVendor", function () {
            $.ajax({
                url: "<?php echo e(route('vendor.edit')); ?>", // Laravel route for editing vendor
                type: "GET",
                data: { id: $(this).data("id") },
                dataType: "json",
                success: function (response) {
                    $('#vendorModal').modal('show');
                    $("#vendor_name").val(response.data.vendor_name);
                    $("#vendor_companyname").val(response.data.vendor_companyname);
                    $("#vendor_companyaddress").val(response.data.vendor_companyaddress);
                    $("#vendor_GST").val(response.data.vendor_GST);
                    $("#vendor_currency").val(response.data.vendor_currency);
                    $('#vendor_id').val(response.data.id);
                },
                error: function () {
                    alert("Something went wrong!");
                }
            });
        });
      </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme-layouts.theme-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding-Language-Learn\IMS-Laravel\InvoiceManagementSystem\resources\views/vendors/view.blade.php ENDPATH**/ ?>