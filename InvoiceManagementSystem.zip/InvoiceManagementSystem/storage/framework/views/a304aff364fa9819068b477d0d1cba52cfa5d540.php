

<?php $__env->startSection('content'); ?>
<h2>Product Section</h2>
<br>
<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#productModal">
  Add Product
</button>
      <br>
      <br>
      <div class="table-responsive small">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th scope="col">Sr.no</th>
              <th scope="col">Name</th>
              <th scope="col">Image</th>
              <th scope="col">Unit</th>
              <th scope="col">Price</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php
              $count = 1;
            ?>
            <?php $__currentLoopData = $productList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($count++); ?></td>
              <td><?php echo e($product->name); ?></td>
              <td><img src="<?php echo e(url('storage/uploads/products/' . $product->image)); ?>" width="100" height="100"></td>

              <td><?php echo e($product->unit); ?></td>
              <td><?php echo e($product->price); ?></td>
              <td>
                <a id="editProduct" data-id="<?php echo e($product->id); ?>" class="btn btn-primary btn-sm">Edit</a>
                <a id="deleteProduct" data-id="<?php echo e($product->id); ?>" class="btn btn-danger btn-sm">Delete</a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </tbody>
        </table>
      </div>


      <!-- Modal -->
      <div class="modal fade" id="productModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Add New Vendor</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" id="productForm" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <div class="modal-body">
                <input type="hidden" name="product_id" id="product_id" value="">
                <div class="mb-3">
                  <label for="name" class="form-label">Name</label>
                  <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name" required>
                </div>
                <div class="mb-3">
                  <label for="image" class="form-label">Image</label>
                  <input type="file" name="image" id="image" class="form-control" required>
                  <div id="displayImage"></div>
                </div>
                <div class="mb-3">
                  <label for="vendor_currency" class="form-label">Unit</label>
                  <select class="form-control" id="unit" name="unit" required>
                    <option value="kg">kg</option>
                    <option value="litre">litre</option>
                    <option value="foot">foot</option>
                    <option value="piece">piece</option>
                  </select>
                </div>
                <div class="mb-3">
                  <label for="price" class="form-label">Price</label>
                  <input type="text" class="form-control" id="price" name="price" placeholder="Enter Price" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Product</button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <script>

$("#productForm").validate({
                errorClass: "errorClass",              
                rules: {
                  name: { required: true},
                  image: { 
                      required: function() {
                          return $("#product_id").val() === ""; // Only required if product_id is empty (create mode)
                      } 
                  },
                  unit: { required: true },
                  price: { required: true},
                },
                messages: {
                  name: { required: "Name is required"},
                  image: { required: "Image is required" },
                  unit: { required: "Unit is required" },
                  price: { required: "Price is required" },
                },
                submitHandler: function (form) {
                    $productID = $("#product_id").val();
                    if ($productID) {
                        $url = "<?php echo e(route('product.update')); ?>";
                    } else {
                        $url = "<?php echo e(route('product.store')); ?>";
                    }
                    var formdata = new FormData();
                    formdata.append("name", $("#name").val());
                    formdata.append("image", $("#image")[0].files[0]);
                    formdata.append("unit", $("#unit").val());
                    formdata.append("price", $("#price").val());
                    formdata.append("product_id", $("#product_id").val());
                    
                    $.ajax({
                        url: $url, // Laravel route for storing vendor
                        type: "POST",
                        data: formdata,
                        contentType: false,
                        processData: false,
                        dataType: "json",
                        headers: {
                            "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
                        },
                        beforeSend: function () {
                            $(".btn-primary").prop("disabled", true).text("Saving...");
                        },
                        success: function (response) {
                          
                            if (response.status === "success") {
                              if ($productID) {
                                alert("Product updated successfully!");
                              }else{
                                alert("Product added successfully!");
                              }
                                $("#exampleModal").modal("hide");
                                $("#productForm")[0].reset();
                            } else {
                                $("#errorMessages").removeClass("d-none").html(response.message);
                            }
                        },
                        error: function (xhr) {
                            let errors = xhr.responseJSON.errors;
                            let errorMessage = "<ul>";
                            $.each(errors, function (key, value) {
                                errorMessage += "<li>" + value[0] + "</li>";
                            });
                            errorMessage += "</ul>";
                            $("#errorMessages").removeClass("d-none").html(errorMessage);
                        },
                        complete: function () {
                            $(".btn-primary").prop("disabled", false).text("Save Vendor");
                        }
                    });
                }
            });


        $(document).on("click", "#deleteProduct", function () {
            if (confirm("Are you sure you want to delete this product?")) {
                $.ajax({
                    url: "<?php echo e(route('product.delete')); ?>", // Laravel route for deleting vendor
                    type: "POST",
                    data: { id: $(this).data("id") },
                    dataType: "json",
                    headers: {
                        "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
                    },
                    success: function (response) {
                        if (response.status === "success") {
                            alert("Product deleted successfully!");
                        } else {
                            alert("Something went wrong!");
                        }
                    },
                    error: function () {
                        alert("Something went wrong!");
                    }
                });
            }
        });

        $(document).on("click", "#editProduct", function () {
            $.ajax({
                url: "<?php echo e(route('product.edit')); ?>", // Laravel route for editing vendor
                type: "GET",
                data: { id: $(this).data("id") },
                dataType: "json",
                success: function (response) {
                    $('#productModal').modal('show');
                    $("#name").val(response.data.name);
                    $("#image").attr("src", response.data.image);
                    $('#displayImage').html('<img src="<?php echo e(url('storage/uploads/products/')); ?>/' + response.data.image + '" width="100" height="100">');
                    // $("#image").val(response.data.image);
                    $("#unit").val(response.data.unit);
                    $("#price").val(response.data.price);
                    $('#product_id').val(response.data.id);
                },
                error: function () {
                    alert("Something went wrong!");
                }
            });
        });
      </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme-layouts.theme-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Coding-Language-Learn\IMS-Laravel\InvoiceManagementSystem\resources\views/products/view.blade.php ENDPATH**/ ?>