<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\VendorController;
use App\Http\Controllers\InvoiceController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [HomeController::class, 'index'])->name('home');
// Vendor
Route::get('/vendor', [VendorController::class, 'ViewVendor']);
Route::post('/vendor/create', [VendorController::class, 'CreateVendor'])->name('vendor.store');
Route::post('/vendor/delete', [VendorController::class, 'DeleteVendor'])->name('vendor.delete');
Route::get('/vendor/edit', [VendorController::class, 'EditVendor'])->name('vendor.edit');
Route::post('/vendor/update', [VendorController::class, 'UpdateVendor'])->name('vendor.update');

// Product
Route::get('/product', [ProductController::class, 'ViewProduct']);
Route::post('/product/create', [ProductController::class, 'CreateProduct'])->name('product.store');
Route::post('/product/delete', [ProductController::class, 'DeleteProduct'])->name('product.delete');
Route::get('/product/edit', [ProductController::class, 'EditProduct'])->name('product.edit');
Route::post('/product/update', [ProductController::class, 'UpdateProduct'])->name('product.update');

// Invoice
Route::get('/invoice', [InvoiceController::class, 'ViewInvoice']);
Route::post('/invoice/create', [InvoiceController::class, 'storeInvoice'])->name('invoice.store');
Route::get('/invoice/edit', [InvoiceController::class, 'EditInvoice'])->name('invoice.edit');
Route::post('/invoice/update', [InvoiceController::class, 'UpdateInvoice'])->name('invoice.update');
// Route::post('/invoice/delete', [InvoiceController::class, 'DeleteInvoice'])->name('invoice.delete');
Route::get('/invoice/download/{id}', [InvoiceController::class, 'downloadInvoice'])->name('invoice.download');
Route::get('/send-invoice/{id}', [InvoiceController::class, 'sendInvoice'])->name('invoice.send');