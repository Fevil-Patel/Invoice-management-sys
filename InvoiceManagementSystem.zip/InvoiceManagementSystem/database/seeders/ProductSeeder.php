<?php

namespace Database\Seeders;

use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {   
        $now = Carbon::now();

        $products = [
            ['Apple', 'apple.jpg', 'kg', 3.99],
            ['Milk', 'milk.jpg', 'litre', 1.50],
            ['Wooden Plank', 'wooden_plank.jpg', 'foot', 5.00],
            ['Notebook', 'notebook.jpg', 'piece', 2.00]
        ];

        DB::table('products')->insert(array_map(fn($p) => [
            'name' => $p[0], 'image' => $p[1], 'unit' => $p[2], 'price' => $p[3],
            'created_at' => $now, 'updated_at' => $now
        ], $products));
    }
}
